                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2490018
 Titan Aero 27mm Piezo Z probe Bracket by m1n1m is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Mount for Titan Aero with a 27mm Piezo sensor from https://www.precisionpiezo.co.uk/ . Does not need a drilled sensor. 

The design is tested on 60mm/s with 160mm/s movement speed on a 3dbenchy without showing any visible "wobble" due to the lesser strenght for the piezo to be triggered.While probing I get a deviation of 0.003mm (from Z-0.098 to Z-0.101) when probing the same spot on and on.   

It is designed to fit my Flashforge creator pro but it will fit other mounts with this style of clamping aswell. Let me know if you need small changes to the design and I'll upload that. 

Ideas came from the part I remixed that Moriquendi made so all credit goes there. 

Video of the mount in action: 
https://www.youtube.com/watch?v=Emi0pRuY6gU

titan_aero_holder.stl - First version, more solid 
totan_aero_holder_v5.stl - Second version, designed to put more force on piezo disk. (doubt it's really needed)